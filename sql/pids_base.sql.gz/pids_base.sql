-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Sam 20 Avril 2013 à 12:09
-- Version du serveur: 5.1.54
-- Version de PHP: 5.3.5-1ubuntu7.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `pids`
--

-- --------------------------------------------------------

--
-- Structure de la table `pids_items`
--

CREATE TABLE IF NOT EXISTS `pids_items` (
  `id_item` int(4) NOT NULL AUTO_INCREMENT,
  `id_pid` int(4) NOT NULL,
  `cat_item` varchar(20) NOT NULL,
  `name_item` varchar(255) NOT NULL,
  `id_type` int(3) NOT NULL,
  `max_item` int(3) NOT NULL,
  `min_item` int(3) NOT NULL,
  `multiplier_item` int(3) NOT NULL,
  PRIMARY KEY (`id_item`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `pids_items`
--

INSERT INTO `pids_items` (`id_item`, `id_pid`, `cat_item`, `name_item`, `id_type`, `max_item`, `min_item`, `multiplier_item`) VALUES
(1, 1, 'set_request', 'serial_number', 4, 0, 0, 0),
(2, 2, 'get_response', 'mode', 2, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `pids_itemsrange`
--

CREATE TABLE IF NOT EXISTS `pids_itemsrange` (
  `id_range` int(4) NOT NULL AUTO_INCREMENT,
  `id_item` int(4) NOT NULL,
  `cat_range` varchar(20) NOT NULL,
  `value_range` varchar(255) NOT NULL,
  `value2_range` varchar(255) NOT NULL,
  PRIMARY KEY (`id_range`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `pids_itemsrange`
--

INSERT INTO `pids_itemsrange` (`id_range`, `id_item`, `cat_range`, `value_range`, `value2_range`) VALUES
(1, 2, 'labels', '0', 'DMX512'),
(2, 2, 'labels', '1', 'DALI'),
(3, 2, 'labels', '2', 'DSI');

-- --------------------------------------------------------

--
-- Structure de la table `pids_list`
--

CREATE TABLE IF NOT EXISTS `pids_list` (
  `id_pid` int(4) NOT NULL AUTO_INCREMENT,
  `id_manufact` int(3) NOT NULL,
  `value_pid` varchar(10) NOT NULL,
  `name_pid` varchar(255) NOT NULL,
  `notes_pid` longtext NOT NULL,
  `link_pid` tinytext NOT NULL,
  `subget_pid` int(3) NOT NULL,
  `subset_pid` int(3) NOT NULL,
  `get_pid` tinyint(1) NOT NULL,
  `set_pid` tinyint(1) NOT NULL,
  `samegs_pid` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `pids_list`
--

INSERT INTO `pids_list` (`id_pid`, `id_manufact`, `value_pid`, `name_pid`, `notes_pid`, `link_pid`, `subget_pid`, `subset_pid`, `get_pid`, `set_pid`, `samegs_pid`) VALUES
(1, 1, '0x8000', 'SERIAL_NUMBER', 'Sets the serial number (UID) of the device.', 'http://opendmx.net/index.php/Open_Lighting_PIDs', 0, 1, 0, 1, 0),
(2, 2, '32768', 'DEVICE_MODE', 'Controls the operating mode of the device', 'http://www.creativelighting.com.au/', 2, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `pids_manufact`
--

CREATE TABLE IF NOT EXISTS `pids_manufact` (
  `id_manufact` int(3) NOT NULL AUTO_INCREMENT,
  `rdmid_manufact` varchar(10) NOT NULL,
  `name_manufact` varchar(150) NOT NULL,
  PRIMARY KEY (`id_manufact`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `pids_manufact`
--

INSERT INTO `pids_manufact` (`id_manufact`, `rdmid_manufact`, `name_manufact`) VALUES
(1, '0x7a70', 'Open Lighting'),
(2, '0x00a1', 'Creative Lighting');

-- --------------------------------------------------------

--
-- Structure de la table `pids_type`
--

CREATE TABLE IF NOT EXISTS `pids_type` (
  `id_type` int(3) NOT NULL AUTO_INCREMENT,
  `name_type` varchar(50) NOT NULL,
  `desc_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Contenu de la table `pids_type`
--

INSERT INTO `pids_type` (`id_type`, `name_type`, `desc_type`) VALUES
(1, 'bool', ''),
(2, 'uint8', ''),
(3, 'uint16', ''),
(4, 'uint32', ''),
(5, 'string', ''),
(6, 'group', ''),
(7, 'int8', ''),
(8, 'int16', ''),
(9, 'int32', ''),
(10, 'ipv4', ''),
(11, 'uid', '');
